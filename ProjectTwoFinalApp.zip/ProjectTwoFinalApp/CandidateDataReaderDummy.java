// --== CS400 File Header Information ==--
// Name: Peichuan Yang
// Email: pyang248@wisc.edu
// Team: AC Red
// Role: Integration manager
// TA: Mu
// Lecturer: Florian
// Notes to Grader: <optional extra notes>
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;


public class CandidateDataReaderDummy implements CandidateDataReaderInterface{

  /**
   * Method that reads job candidate data in CSV format from the Reader provided. The dummy implementations
   * will always return the same 3 sets of job candidates
   */
  @Override
  public ArrayList<Candidate> getData(String filename) throws FileNotFoundException, IOException {
    ArrayList<Candidate> candidate = new ArrayList<Candidate>();
    candidate.add(new Candidate(filename, 0, filename, filename, filename, null) {

      @Override
      public String getName() {
          return "James Jobs";
      }

      @Override
      public int getRating() {
          return 68;
      }

      @Override
      public String getWorkExperience() {
          return "No working experience.";
      }

      @Override
      public String getEducationBackground() {
          return "Undergraduate from UIUC";
      }

      @Override
      public String getPosition() {
          return "Programmer";
      }
      
      @Override
      public int getAge() {
        return 22;
      }
      
      @Override 
      public String toString() {
        return "James Jobs" + " | " + 22 + " | " + "No working experience." + " | " + "Undergraduate from UIUC" + " | " + "Programmer"+" | " +  68;
      }
       
      

      @Override
      public int compareTo(CandidateInterface otherCandidate) {
        if(this.getRating()>otherCandidate.getRating()) return -1;
        else if (this.getRating() == otherCandidate.getRating()) return 0;
        return 1;
      }
      
  });
  candidate.add(new Candidate(filename, 0, filename, filename, filename, null) {

    @Override
    public String getName() {
        return "Steve Robinson";
    }

    @Override
    public int getRating() {
        return 87;
    }

    @Override
    public String getWorkExperience() {
        return "2 years in Microsoft";
    }

    @Override
    public String getEducationBackground() {
        return "Graduate from UWM";
    }
    @Override
    public String getPosition() {
        return "Senior Software Engineer";
    }

    @Override
    public int getAge() {
      return 31;
    }
    
    @Override 
    public String toString() {
      return "Steve Robinson" + " | " + 31 + " | " + "2 years in Microsoft" + " | " + "Graduate from UWM" + " | " + "Senior Software Engineer" +" | " +  87;
    }
    
    @Override
    public int compareTo(CandidateInterface otherCandidate) {
      if(this.getRating()>otherCandidate.getRating()) return -1;
      else if (this.getRating() == otherCandidate.getRating()) return 0;
      return 1;
    }

  });
 candidate.add(new Candidate(filename, 0, filename, filename, filename, null) {

   @Override
   public String getName() {
       return "Yoshima Naruto";
   }

   @Override
   public int getRating() {
       return 77;
   }

   @Override
   public String getWorkExperience() {
       return "4 years in Riot Games";
   }

   @Override
   public String getEducationBackground() {
       return "Undergraduate from CMU";
   }

   @Override
   public String getPosition() {
       return "Program Manager";
   }

   @Override
   public int getAge() {
     return 26;
   }
   
   @Override 
   public String toString() {
     return "Yoshima Naruto" + " | " + 26 + " | " + "4 years in Riot Games" + " | " + "Undergraduate from CMU" + " | " + "Program Manager" + " | " +  77;
   }

   @Override
   public int compareTo(CandidateInterface otherCandidate) {
     if(this.getRating()>otherCandidate.getRating()) return -1;
     else if (this.getRating() == otherCandidate.getRating()) return 0;
     return 1;
   }

  });
  return candidate;
}

}

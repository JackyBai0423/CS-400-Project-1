public interface CandidateInterface extends Comparable<CandidateInterface>{
  public String getName();
  public int getRating();
  public String getWorkExperience();
  public String getEducationBackground();
  public String getPosition();
  public int getAge();
  public int compareTo(CandidateInterface otherCandidate);
  @Override
  public String toString();
}

// --== CS400 File Header Information ==--
// Name: Jacky Bai
// Email: bai59@wisc.edu
// Team: red
// Group: AC
// TA: Mu
// Lecturer: Florian Heimerl
// Notes to Grader: None

import org.junit.Test;
import java.util.ArrayList;

import static org.junit.Assert.fail;

public class DataWranglerTests {

  public static void main(String[] args) {
    new DataWranglerTests().runTest();
  }

  private void runTest(){
    testCandidate();
    testRatingCandidate();
    testReadCandidate();
    testReadCandidateName();
    testReadNumberOfCandidate();
  }


  /**
   * test whether the candidate can be successfully read.
   */
  @Test
  public void testReadCandidate(){
    Candidate c1 = new Candidate("James-Jobs",22,"No working experience.","Undergraduate from UIUC","Programmer",68);
    Candidate c2 = new Candidate("Gimgoon",24,"2 years in LPL as a professional player","No degree","Game Tester",83);
    ArrayList<Candidate> result = new ArrayList<>();
    try{
      result = new CandidateDataReader().getData("src/datasheet_candidate.csv");
    } catch (Exception e) {
      e.printStackTrace();
      fail("Exception");
    }
    if(!result.get(0).toString().equals(c1.toString())
    ||!result.get(13).toString().equals(c2.toString()))
    fail("The expected candidates not found");
  }

  /**
   * test whether the number of candidates read from dataset is correct
   */
  @Test
  public void testReadNumberOfCandidate(){
    ArrayList<Candidate> result = new ArrayList<>();
    try{
      result = new CandidateDataReader().getData("src/datasheet_candidate.csv");
    } catch (Exception e) {
      e.printStackTrace();
      fail("Exception");
    }
    if(result.size()!=19)
      fail("Incorrect size.");
  }

  /**
   * test whether the Candidate class work
   */
  @Test
  public void testCandidate(){
    Candidate c1 = new Candidate("James-Jobs",22,"No working experience.","Undergraduate from UIUC","Programmer",68);
    if(!c1.toString().equals("James-Jobs" + " | " + 22 + " | " + "No working experience." + " | " + "Undergraduate from UIUC" + " | " + "Programmer"+" | " +  68))
      fail("Failed to construct the candidate");
  }

  /**
   * test getting the correcting rating of Candidate
   */
  @Test
  public void testRatingCandidate(){
    ArrayList<Candidate> result = new ArrayList<>();
    try{
      result = new CandidateDataReader().getData("src/datasheet_candidate.csv");
    } catch (Exception e) {
      e.printStackTrace();
      fail("Exception");
    }
    if(result.get(0).getRating()!=68
    ||result.get(1).getRating()!=87)
      fail("Failed to get the correct rating.");
  }

  /**
   * test whether the name of candidates can be read successfully.
   */
  @Test
  public void testReadCandidateName(){
    ArrayList<Candidate> result = new ArrayList<>();
    try{
      result = new CandidateDataReader().getData("src/datasheet_candidate.csv");
    } catch (Exception e) {
      e.printStackTrace();
      fail("Exception");
    }
    if(!result.get(0).getName().equals("James-Jobs")
        ||!result.get(1).getName().equals("Steve-Robinson"))
      fail("Failed to get the correct name.");
  }
}

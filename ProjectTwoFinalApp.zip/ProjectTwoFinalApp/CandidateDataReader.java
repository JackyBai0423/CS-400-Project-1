import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class CandidateDataReader implements CandidateDataReaderInterface{

  BufferedReader reader;

  @Override
  public ArrayList<Candidate> getData(String filename) throws FileNotFoundException, IOException {
    reader = new BufferedReader(new FileReader(filename)); // "datasheet_candidate.csv"
    ArrayList<Candidate> candidates = new ArrayList<>();

    try{
      this.reader.readLine();
      String[] result;
      char c;
      while((c = (char) reader.read()) != -1){
        String line = c + reader.readLine();
        if(line == null) break;
        result = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
        if(result.length!=6) break;
        if(result[2].toCharArray()[0]=='\"') result[2] = result[2].substring(1, result[2].toCharArray().length-1);
        candidates.add(new Candidate(result[0], Integer.parseInt(result[1]), result[2], result[3], result[4], Integer.parseInt(result[5])));
      }
    } catch (IOException e) {

    } finally {
      try{
        if(this.reader!=null) this.reader.close();
      }catch (IOException e){
        e.printStackTrace();
      }
    }

    return candidates;
  }

//  public static void main(String[] args) {
//    CandidateDataReader r = new CandidateDataReader();
//    try {
//      ArrayList<Candidate> result = r.getData("src/datasheet_candidate.csv");
//      System.out.println(result.size());
//      for(Candidate i: result){
//        System.out.println(i.toString());
//      }
//    } catch (Exception e){
//      e.printStackTrace();
//    }
//  }
}
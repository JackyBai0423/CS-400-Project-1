// --== CS400 File Header Information ==--
// Name: Peiyuan Li
// Email: pli233@wisc.edu
// Team: AC
// Role: Frontend Developer
// TA: Mu
// Lecturer: Florian Heimerl

import java.util.Scanner;
import java.util.ArrayList;
/** This class will simulate as a UI
 * it will provide two opertaions and 1 extra mode
 * 
 * @author Peiyuan Li
 *
 */

public class Frontend{
    
    
    /**
     * main method that run the run method
     * @param args
     */
  public static void main(String[] args) {
    try{
      run(new Backend());
    } catch (Exception e){
        System.out.println(e.getMessage());
    }
  }
  
  /**
   * load the application, start at base mode, press "x" to quit,
   * press "r" to show a list with descending rating , press "a" to show a list with ascending age
   * press "n" to enter name search mode
   * age selection mode.
   * @param backend 
   */
  public static void run(Backend backend) {
    
    Scanner scan = new Scanner(System.in);
    String mode = "d";
    
    while (true){
      boolean iscontinue = true;
      System.out.println("Please select a option:\n "+ "Now you are at the default page\n r: show a descending rating list\n a: show an descending age list\n n: enter name search mode \n");
      System.out.println("--------------------------------------------------");
      System.out.println("If you want to exit the program, press x");
      String input = "";
      if(scan.hasNextLine()) input = scan.next(); // scan for input
      if(!input.equals("a") && !input.equals("r") && !input.equals("n")&& !input.equals("x")) { 
          System.out.println("Invalid input"); 
          System.out.println();
          System.out.println();
          System.out.println();
          System.out.println("--------------------------------------------------");
      }
      else {
        mode = input;
        if(mode.equals("x")) { // quit the application
          break;
        }
      }
      switch (mode) {
        //Display all candidates with age in descending order
        case "a":
        {   
            
            System.out.println("Here are the candidates information arranged by age in descending order");
            System.out.println(backend.getAllAges());
            while(iscontinue) {
            String in = scan.next();
                if(in.equals("x")) {
                    mode = "d"; // press "x" to return to default page
                    iscontinue= false;
                }else {
                    System.out.println("You can enter x to return to the default page");
                }
            
            }
            if(!iscontinue) {
                iscontinue=true;
                break;
            }
        }
        //Display all candidate with rating in descending order
        case "r":
        {
            System.out.println("Here are the candidates information arranged by rating in descending order");
            System.out.println(backend.getAllRatings());
            while(iscontinue) {
            String in = scan.next();
                    if(in.equals("x")) {
                        mode = "d"; // press "x" to return to default page
                        iscontinue= false;
                    }else {
                        System.out.println("You can enter x to return to the default page");
                    }
                
                }
                if(!iscontinue) {
                    iscontinue=true;
                    break;
                }
      }
      //Enter name search mode
      case "n":
        {
            while(true) {
            System.out.println("Enter the name of the candidate you want to know more about");
            System.out.println("If you want to exit the name search mode, press x");    
            // show all of the genre to be select
            String in = scan.next();
            if(!in.equals("x") && in!=null) {
                try {
                    System.out.println(backend.getSingleInfo(in));
                    System.out.println("--------------------------------------------------");
                }catch(Exception e) {
                    System.out.println("The input name is not found in the file");
                    System.out.println("--------------------------------------------------");
                    mode="n";
                }
            } 
            else if(in.equals("x")) 
            {
              // press "x" to return to default page
              mode = "d"; 
              break;
            }
           }
      }
    }
  }
 }
}

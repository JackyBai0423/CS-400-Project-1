DataWrangler README for Project Two (CS400 @ UW Madison)
========================================================

Name of DataWrangler: Jacky Bai
@wisc.edu Email of DataWrangler: bai59@wisc.edu
Group: AC
Team: Red
Files Written by Me: Candidate.java CandidateDataReader.java CandidateDataReaderInterface.java datasheet_candidate.csv
--------------------
Candidate.java: Candidate class to save the data for a candidate
CandidateDataReader.java: reading the data from the .csv file
CandidateDataReaderInterface.java: interface of the reader.
datasheet_candidate.csv: Dataset that contains data of the candidates.
Additional Contributions:
-------------------------
Assisting team with the final integrating

Signature: Jacky Bai
----------
<Type out your full name here to certify that all of the files written by you
 that are listed above are the product of your individual development efforts
 for this programming assignment.  List below your name, any exceptions, for 
 example: work reused from a previous semester, code examples taken from any 
 website or book, or anything that was not explicitly authored by you for
 the purpose of completing this assigned CS400 project.>
Some of the ideas in our project two are from our project one.
 

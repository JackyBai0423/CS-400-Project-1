// --== CS400 File Header Information ==--
// Name: Jianbang Sun
// Email: jsun326@wisc.edu
// Team: AC Red
// Role: Backend Developer
// TA: Mu
// Lecturer: Florian
// Notes to Grader: <optional extra notes>

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

public class Backend implements BackendInterface{
    
    private String fileName;
    private List<Integer> ages; 
  private List<Integer> ratings; 
  private List<Candidate> Candidates;
  private RedBlackTree<CandidateInterface> RBT;
  
  /**
   * Constructor of Backend
   */
  public Backend() {
    ages = new ArrayList<>();
    ratings = new ArrayList<>();
    Candidates = new ArrayList<>();
    RBT = new RedBlackTree<>();
    fileName = "src/datasheet_candidate.csv";
    try{
      Candidates = new CandidateDataReader().getData(fileName);
    } catch (Exception e){
      e.printStackTrace();
    }
    for (CandidateInterface c : Candidates) {
        RBT.insert(c);
    }
  }
  
    @Override
    public void addAge(Integer age) {
        ages.add(age);
    }

    @Override
    public void addRating(Integer rating) {
        ratings.add(rating);
    }

    @Override
    public List<Integer> getAge() {
        for(int i = 0; i < Candidates.size(); i++) {
        if(Candidates.get(i) != null) {
            ages.add(Candidates.get(i).getAge());
        }
    }
        return ages;
    }

    @Override
    public List<Integer> getRatings() {
        for(int i = 0; i < Candidates.size(); i++) {
        if(Candidates.get(i) != null) {
            ratings.add(Candidates.get(i).getRating());
        }
    }
        return ratings;
    }

    @Override
    public int getNumberOfCandidates() {
        return Candidates.size();
    }

    @Override
    public String getAllAges() {
        try{
        String result = "";
        Candidates.sort(new Comparator<CandidateInterface>() {
          @Override
          public int compare(CandidateInterface c1, CandidateInterface c2) {
            if(c1.getAge() > c2.getAge()) return -1;
            else if (c1.getAge() == c2.getAge()) return 0;
            return 1;
          }
        });
        for(int i = 0; i < Candidates.size(); i++) {
          if(Candidates.get(i) != null) {
            result = result + Candidates.get(i).toString() + "\n";
          }
        }
        return result;
        }catch (Exception e){
          System.out.println(e.getMessage());;
        }
        return null;
    }

    @Override
    public String getAllRatings() {
        try{
        String result = "";
        Candidates.sort(new Comparator<CandidateInterface>() {
          @Override
          public int compare(CandidateInterface c1, CandidateInterface c2) {
            if(c1.getRating()>c2.getRating()) return -1;
            else if (c1.getRating() == c2.getRating()) return 0;
            return 1;
          }
        });
        for(int i = 0; i < Candidates.size(); i++) {
          if(Candidates.get(i) != null) {
            result = result + Candidates.get(i).toString() + "\n";
          }
        }
        return result;
        }catch (Exception e){
          System.out.println(e.getMessage());;
        }
        return null;
    }

    @Override
    public String getSingleInfo(String name) {
        if (name == null) {
            throw new IllegalArgumentException("Invalid input");
        }
        return recursiveHelper(RBT.root, name).data.toString();
    }
    
    public Node<CandidateInterface> recursiveHelper(Node<CandidateInterface> node, String name) {
        if (node == null) {
            return null;
        } else if (node.data.getName().equals(name)){
            return node;
        } else {
            Node<CandidateInterface> leftResult = recursiveHelper(node.leftChild, name);
            if (leftResult != null) {
                return leftResult;
            }
            return recursiveHelper(node.rightChild, name);
        }
        
    }
}

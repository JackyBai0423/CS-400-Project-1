import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public interface CandidateDataReaderInterface {
  public ArrayList<Candidate> getData(String filename) throws FileNotFoundException, IOException;
}
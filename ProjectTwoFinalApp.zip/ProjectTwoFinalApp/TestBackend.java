// --== CS400 File Header Information ==--
// Name: Jianbang Sun
// Email: jsun326@wisc.edu
// Team: AC Red
// Role: Backend Developer
// TA: Mu
// Lecturer: Florian
// Notes to Grader: <optional extra notes>
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * This class tests whether the methods in the Backend Class work as expected
 * @author Jianbang Sun
 *
 */
public class TestBackend {
    
    Backend backend;
    @Before
    public void setUp() {
        backend = new Backend();
    }
    
    /**
     * Test whether the getAge () method correctly returns all ages when it is called
     * This test will fail if the return value is not expected.
     */
    @Test
    public void testGetAge() {
    try {
        List<Integer> list = Arrays.asList(22, 31, 26, 33, 19, 28, 40, 80, 21, 38, 38, 20, 29, 24, 27, 31, 56, 30, 25);
        assertEquals(backend.getAge(), list);
    } catch (Exception e){
        System.out.println(e.getMessage());
    }
    System.out.println("testGetAge passed");
    }
    
    /**
     * Test whether the getRating () method correctly returns all ratings when it is called
     * This test will fail if the return value is not expected.
     */
    @Test
    public void testGetRating() {
    try {
        Backend backend = new Backend();
        List<Integer> list = Arrays.asList(68, 87, 77, 89, 34, 76, 92, 0, 62, 88, 86, 94, 82, 83, 50, 60, 23, 93, 91);
        assertEquals(backend.getRatings(), list);
    } catch (Exception e){
        System.out.println(e.getMessage());
    }
    System.out.println("testGetRatings passed");
    }
    
    /**
     * Tests that when the getAllAges() method is called, 
     * the method returns information about all the candidates, 
     * sorted top to bottom by age.
     * This test will fail if the return value is not expected.
     */
    @Test
    public void testGetAllAges() {
        try {
            Backend backend = new Backend();
            String str = "Vincent-Collector | 80 | 57 years in Gameloft | PhD from Cornell University | Programmer | 0\r\n" +
                    "Donald-Trump | 56 | 4 years as US president | No degree | Data wrangler | 23\r\n" +
                    "Jason-Kazz | 40 | 15 years in New York Times | PhD from Harvard University | Main Designer | 92\r\n" +
                    "Darius  | 38 | 8 years in Riot Game's Kitchen | No degree | Cook | 88\r\n" + 
                    "Galen | 38 | 8 years in Riot Game as a cleaner | No degree | Cleaner | 86\r\n" + 
                    "Sun-Bofu | 33 | 10 years in Google | Graduate from Jiangdong University | Main Designer | 89\r\n" +
                    "Steve-Robinson | 31 | 2 years in Microsoft, 3 years in Apple. | Graduate from UWM | Senior Software Engineer | 87\r\n" +
                    "Wu-Yifan | 31 | No working experience. | No degree | Cook | 60\r\n" +
                    "Kujo-Jotaro | 30 | 10 years as an oceanologist | PhD in UCBerkerley | Game Tester | 93\r\n" +
                    "Lee-Sin | 29 | 7 years in Facebook | Graduate from UW | Program Manager | 82\r\n" +
                    "Peter-Parker | 28 | 6 years in Marvel Studio | Graduate from Spider University | Programmer | 76\r\n" +
                    "Wang-Sicong | 27 | No working experience. | Undergraduate from UCL | Programmer | 50\r\n" +
                    "Yoshima-Naruto | 26 | 4 years in Riot Games | Undergraduate from CMU | Program Manager | 77\r\n" +
                    "Miss-Fortune | 25 | 5 years as a professional shooter | No degree | Game Tester | 91\r\n" +
                    "Gimgoon | 24 | 2 years in LPL as a professional player | No degree | Game Tester | 83\r\n" + 
                    "James-Jobs | 22 | No working experience. | Undergraduate from UIUC | Programmer | 68\r\n" +
                    "Seraphine | 21 | 1 year in KDA | Undergraduate from Umich | Musician | 62\r\n" + 
                    "Rookie | 20 | 3 years in LPL as a professional player | No degree | Game Tester | 94\r\n" + 
                    "Kelvin-Dell | 19 | No working experience. | Senior high school graduate | Data wrangler | 34\r\n";
            String str1 = backend.getAllAges();
            assertEquals(backend.getAllAges(), str1);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println("testGetAllAge passed");
    }
    
    /**
     * Tests that when the getAllRatings() method is called, 
     * the method returns information about all the candidates, 
     * sorted top to bottom by rating.
     * This test will fail if the return value is not expected.
     */
    @Test
    public void testGetAllRatings() {
        try {
            Backend backend = new Backend();
            String str = "Rookie | 20 | 3 years in LPL as a professional player | No degree | Game Tester | 94\r\n" +
                    "Kujo-Jotaro | 30 | 10 years as an oceanologist | PhD in UCBerkerley | Game Tester | 93\r\n" +
                    "Jason-Kazz | 40 | 15 years in New York Times | PhD from Harvard University | Main Designer | 92\r\n" +
                    "Miss-Fortune | 25 | 5 years as a professional shooter | No degree | Game Tester | 91\r\n" +
                    "Sun-Bofu | 33 | 10 years in Google | Graduate from Jiangdong University | Main Designer | 89\r\n" +
                    "Darius  | 38 | 8 years in Riot Game's Kitchen | No degree | Cook | 88\r\n" +
                    "Steve-Robinson | 31 | 2 years in Microsoft, 3 years in Apple. | Graduate from UWM | Senior Software Engineer | 87\r\n" +
                    "Galen | 38 | 8 years in Riot Game as a cleaner | No degree | Cleaner | 86\r\n" +
                    "Gimgoon | 24 | 2 years in LPL as a professional player | No degree | Game Tester | 83\r\n" +
                    "Lee-Sin | 29 | 7 years in Facebook | Graduate from UW | Program Manager | 82\r\n" +
                    "Yoshima Naruto | 26 | 4 years in Riot Games | Undergraduate from CMU | Program Manager | 77\r\n" +
                    "Peter-Parker | 28 | 6 years in Marvel Studio | Graduate from Spider University | Programmer | 76\r\n" +
                    "James-Jobs | 22 | No working experience. | Undergraduate from UIUC | Programmer | 68\r\n" +
                    "Seraphine | 21 | 1 year in KDA | Undergraduate from Umich | Musician | 62\r\n" +
                    "Wu-Yifan | 31 | No working experience. | No degree | Cook | 60\r\n" +
                    "Wang-Sicong | 27 | No working experience. | Undergraduate from UCL | Programmer | 50\r\n" +
                    "Kelvin-Dell | 19 | No working experience. | Senior high school graduate | Data wrangler | 34\r\n" +
                    "Donald-Trump | 56 | 4 years as US president | No degree | Data wrangler | 23\r\n" +
                    "Vincent-Collector | 80 | 57 years in Gameloft | PhD from Cornell University | Programmer | 0\r\n" +
                    "";
            String str1 = backend.getAllRatings();
            assertEquals(backend.getAllRatings(), str1);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println("testGetAllRatings passed");
    }
    
    /**
     * Test whether the getSingleInfo () method returns the correct Candidate information 
     * when it is called with the correct name.
     * This test will fail if incorrect infomation is returned.
     */
    @Test
    public void testGetSingleInfo() {
        try {
            Backend backend = new Backend();
            assertEquals(backend.getSingleInfo("Rookie"), "Rookie | 20 | 3 years in LPL as a professional player | No degree | Game Tester | 94");
            assertEquals(backend.getSingleInfo("Gimgoon"), "Gimgoon | 24 | 2 years in LPL as a professional player | No degree | Game Tester | 83");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println("testGetSingleInfo passed");
    }
}


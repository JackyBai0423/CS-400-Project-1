// --== CS400 File Header Information ==--
// Name: Peichuan Yang
// Email: pyang248@wisc.edu
// Team: AC Red
// Role: Integration manager
// TA: Mu
// Lecturer: Florian
// Notes to Grader: <optional extra notes>
import java.util.List;

public class BackendDummy implements BackendInterface{

  /**
   * This constructor instantiates a backend with the command line arguments
   * passed to the app when started by the user. The arguments are expected
   * to contain the path to the data file that the backend will read in.
   * @param args list of command line arguments passed to front end
   */
  public BackendDummy(String[] args) {
          System.out.println("Dummy backend; ignoring file paths in argument");
    }
  
  /**
   * A constructor that will create a backend from data that can be read in
   * with a reader object.
   * @param r A reader that contains the data in CSV format.
   */
  public BackendDummy(CandidateDataReader r) {
      System.out.println("Dummy backend; ignoring data in argument");
  }
  
  /**
   * Method to add an age that the user selected. 
   */
  @Override
  public void addAge(Integer age) {
    System.out.println("Dummy backend; ignoring data in argument");
  }
  
  /**
   * Method to add a rating that the user selected. 
   */
  @Override
  public void addRating(Integer rating) {
    System.out.println("Dummy backend; ignoring data in argument");
  }

  /**
   * Returns the age of the selected job candidate
   */
  @Override
  public List<Integer> getAge() {
    System.out.println("Dummy backend; ignoring data in argument");
    return null;
  }

  /**
   * Returns the rating of the selected job candidate
   */
  @Override
  public List<Integer> getRatings() {
    System.out.println("Dummy backend; ignoring data in argument");
    return null;
  }

  /**
   * Returns the number of  job candidate
   */
  @Override
  public int getNumberOfCandidates() {
    System.out.println("Dummy backend; ignoring data in argument");
    return 0;
  }

  /**
   * Returns the age of all job candidates 
   */
  @Override
  public String getAllAges() {
    System.out.println("Dummy backend; ignoring data in argument");
    return null;
  }

  /**
   * Returns the rating of all job candidates
   */
  @Override
  public String getAllRatings() {
    System.out.println("Dummy backend; ignoring data in argument");
    return null;
  }
  
  /**
   * Returns the personal info of the selected job candidate
   */
  @Override
  public String getSingleInfo(String Name) {
    System.out.println("Dummy backend; ignoring data in argument");
    return null;
  }



}

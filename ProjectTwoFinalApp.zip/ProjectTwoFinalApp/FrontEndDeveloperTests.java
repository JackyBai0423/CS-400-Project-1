// --== CS400 File Header Information ==--
// Name: Peiyuan Li
// Email: pli233@wisc.edu
// Team: AC
// Role: Frontend Developer
// TA: Mu
// Lecturer: Florian Heimerl
import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Scanner;

import org.junit.Test;
public class FrontEndDeveloperTests {
    

    /**
     * This method will test the string representation of a selected person
     * is correct
     *
     */
    @Test
    public void testDisplayPerson(){
        PrintStream standardOut = System.out;
        InputStream standardIn = System.in;
        try {
            // set the input stream to our input (with an g to test of the program lists genres)
            String input = "n" +System.lineSeparator()+"Rookie"+System.lineSeparator()+"x"+System.lineSeparator()+"x";
            InputStream inputStreamSimulator = new ByteArrayInputStream(input.getBytes());
            System.setIn(inputStreamSimulator);
            ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();
            // set the output to the stream captor to read the output of the front end
            System.setOut(new PrintStream(outputStreamCaptor));
            // instantiate when front end is implemented
            Object frontend = new Frontend();
            ((Frontend)frontend).run(new Backend());
            // set the output back to standard out for running the test
            System.setOut(standardOut);
            // same for standard in
            System.setIn(standardIn);
            // add all tests to this method
            String appOutput = outputStreamCaptor.toString();
//            System.out.print(appOutput);
            if (frontend == null || !(appOutput.contains("Rookie | 20 | 3 years in LPL as a professional player | No degree | Game Tester | 94"))) {
                fail();
            } 
        } catch (Exception e) {
            // make sure stdin and stdout are set correctly after we get exception in test
            System.setOut(standardOut);
            System.setIn(standardIn);
            e.printStackTrace();
            // test failed
            fail();
        }
    }

     /**
         * This method will test the age selection mode return result
         * in order of age, from youngest to oldest
         *
         */
        @Test
        public void testDisplayByAge(){
            PrintStream standardOut = System.out;
            InputStream standardIn = System.in;
            try {
                // set the input stream to our input (with an g to test of the program lists genres)
                String input = "a" +System.lineSeparator()+"x"+System.lineSeparator()+"x";
                InputStream inputStreamSimulator = new ByteArrayInputStream(input.getBytes());
                System.setIn(inputStreamSimulator);
                ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();
                // set the output to the stream captor to read the output of the front end
                System.setOut(new PrintStream(outputStreamCaptor));
                // instantiate when front end is implemented
                Object frontend = new Frontend();
                ((Frontend)frontend).run(new Backend());
                // set the output back to standard out for running the test
                System.setOut(standardOut);
                // same for standard in
                System.setIn(standardIn);
                // add all tests to this method
                String appOutput = outputStreamCaptor.toString();
//                System.out.print(appOutput);
                if (frontend == null || !(appOutput.contains("Vincent-Collector | 80 | 57 years in Gameloft | PhD from Cornell University | Programmer | 0\n"
                        + "Donald-Trump | 56 | 4 years as US president | No degree | Data wrangler | 23\n"
                        + "Jason-Kazz | 40 | 15 years in New York Times | PhD from Harvard University | Main Designer | 92\n"
                        + "Darius  | 38 | 8 years in Riot Game's Kitchen | No degree | Cook | 88\n"
                        + "Galen | 38 | 8 years in Riot Game as a cleaner | No degree | Cleaner | 86\n"
                        + "Sun-Bofu | 33 | 10 years in Google | Graduate from Jiangdong University | Main Designer | 89\n"
                        + "Steve-Robinson | 31 | 2 years in Microsoft, 3 years in Apple. | Graduate from UWM | Senior Software Engineer | 87\n"
                        + "Wu-Yifan | 31 | No working experience. | No degree | Cook | 60\n"
                        + "Kujo-Jotaro | 30 | 10 years as an oceanologist | PhD in UCBerkerley | Game Tester | 93\n"
                        + "Lee-Sin | 29 | 7 years in Facebook | Graduate from UW | Program Manager | 82\n"
                        + "Peter-Parker | 28 | 6 years in Marvel Studio | Graduate from Spider University | Programmer | 76\n"
                        + "Wang-Sicong | 27 | No working experience. | Undergraduate from UCL | Programmer | 50\n"
                        + "Yoshima-Naruto | 26 | 4 years in Riot Games | Undergraduate from CMU | Program Manager | 77\n"
                        + "Miss-Fortune | 25 | 5 years as a professional shooter | No degree | Game Tester | 91\n"
                        + "Gimgoon | 24 | 2 years in LPL as a professional player | No degree | Game Tester | 83\n"
                        + "James-Jobs | 22 | No working experience. | Undergraduate from UIUC | Programmer | 68\n"
                        + "Seraphine | 21 | 1 year in KDA | Undergraduate from Umich | Musician | 62\n"
                        + "Rookie | 20 | 3 years in LPL as a professional player | No degree | Game Tester | 94\n"
                        + "Kelvin-Dell | 19 | No working experience. | Senior high school graduate | Data wrangler | 34"))) {
                    fail();
                } 
            } catch (Exception e) {
                // make sure stdin and stdout are set correctly after we get exception in test
                System.setOut(standardOut);
                System.setIn(standardIn);
                e.printStackTrace();
                // test failed
                fail();
            }
        }

     /**
         * This method will test the rating selection mode return result
         * in order of rating, from youngest to oldest
         *
         */
        @Test
        public void testDisplayByRating(){
            PrintStream standardOut = System.out;
            InputStream standardIn = System.in;
            try {
                // set the input stream to our input (with an g to test of the program lists genres)
                String input = "r" +System.lineSeparator()+"x"+System.lineSeparator()+"x";
                InputStream inputStreamSimulator = new ByteArrayInputStream(input.getBytes());
                System.setIn(inputStreamSimulator);
                ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();
                // set the output to the stream captor to read the output of the front end
                System.setOut(new PrintStream(outputStreamCaptor));
                // instantiate when front end is implemented
                Object frontend = new Frontend();
                ((Frontend)frontend).run(new Backend());
                // set the output back to standard out for running the test
                System.setOut(standardOut);
                // same for standard in
                System.setIn(standardIn);
                // add all tests to this method
                String appOutput = outputStreamCaptor.toString();
//                System.out.print(appOutput);
                if (frontend == null || !(appOutput.contains("Rookie | 20 | 3 years in LPL as a professional player | No degree | Game Tester | 94\n"
                        + "Kujo-Jotaro | 30 | 10 years as an oceanologist | PhD in UCBerkerley | Game Tester | 93\n"
                        + "Jason-Kazz | 40 | 15 years in New York Times | PhD from Harvard University | Main Designer | 92\n"
                        + "Miss-Fortune | 25 | 5 years as a professional shooter | No degree | Game Tester | 91\n"
                        + "Sun-Bofu | 33 | 10 years in Google | Graduate from Jiangdong University | Main Designer | 89\n"
                        + "Darius  | 38 | 8 years in Riot Game's Kitchen | No degree | Cook | 88\n"
                        + "Steve-Robinson | 31 | 2 years in Microsoft, 3 years in Apple. | Graduate from UWM | Senior Software Engineer | 87\n"
                        + "Galen | 38 | 8 years in Riot Game as a cleaner | No degree | Cleaner | 86\n"
                        + "Gimgoon | 24 | 2 years in LPL as a professional player | No degree | Game Tester | 83\n"
                        + "Lee-Sin | 29 | 7 years in Facebook | Graduate from UW | Program Manager | 82\n"
                        + "Yoshima-Naruto | 26 | 4 years in Riot Games | Undergraduate from CMU | Program Manager | 77\n"
                        + "Peter-Parker | 28 | 6 years in Marvel Studio | Graduate from Spider University | Programmer | 76\n"
                        + "James-Jobs | 22 | No working experience. | Undergraduate from UIUC | Programmer | 68\n"
                        + "Seraphine | 21 | 1 year in KDA | Undergraduate from Umich | Musician | 62\n"
                        + "Wu-Yifan | 31 | No working experience. | No degree | Cook | 60\n"
                        + "Wang-Sicong | 27 | No working experience. | Undergraduate from UCL | Programmer | 50\n"
                        + "Kelvin-Dell | 19 | No working experience. | Senior high school graduate | Data wrangler | 34\n"
                        + "Donald-Trump | 56 | 4 years as US president | No degree | Data wrangler | 23\n"
                        + "Vincent-Collector | 80 | 57 years in Gameloft | PhD from Cornell University | Programmer | 0"))) {
                    fail();
                } 
            } catch (Exception e) {
                // make sure stdin and stdout are set correctly after we get exception in test
                System.setOut(standardOut);
                System.setIn(standardIn);
                e.printStackTrace();
                // test failed
                fail();
            }
        }

     /**
         * This method will test the eixt opertaion is working
     * in base mode, press "X" will cause the whole program to be eliminated
     * in rating/age selection mode, press "X" will return to the base mode
         *
         */
        @Test
        public void testExit(){
            PrintStream standardOut = System.out;
            InputStream standardIn = System.in;
            try {
                // set the input stream to our input (with an g to test of the program lists genres)
                String input = "x";
                InputStream inputStreamSimulator = new ByteArrayInputStream(input.getBytes());
                System.setIn(inputStreamSimulator);
                ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();
                // set the output to the stream captor to read the output of the front end
                System.setOut(new PrintStream(outputStreamCaptor));
                // instantiate when front end is implemented
                Object frontend = new Frontend();
                ((Frontend)frontend).run(new Backend());
                // set the output back to standard out for running the test
                System.setOut(standardOut);
                // same for standard in
                System.setIn(standardIn);
                // add all tests to this method
                String appOutput = outputStreamCaptor.toString();
                assertEquals(appOutput,appOutput.toString());
            } catch (Exception e) {
                // make sure stdin and stdout are set correctly after we get exception in test
                System.setOut(standardOut);
                System.setIn(standardIn);
                e.printStackTrace();
                // test failed
                fail();
            }
        }
     /**
         * This method will test the Communication with the back end, run a and r at the same time
         *
         */
        @Test
        public void testGettingData(){
            PrintStream standardOut = System.out;
            InputStream standardIn = System.in;
            try {
                // set the input stream to our input (with an g to test of the program lists genres)
                String input = "r" +System.lineSeparator()+"x"+System.lineSeparator()+"a"+System.lineSeparator()+"x" +System.lineSeparator()+"x";
                InputStream inputStreamSimulator = new ByteArrayInputStream(input.getBytes());
                System.setIn(inputStreamSimulator);
                ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();
                // set the output to the stream captor to read the output of the front end
                System.setOut(new PrintStream(outputStreamCaptor));
                // instantiate when front end is implemented
                Object frontend = new Frontend();
                ((Frontend)frontend).run(new Backend());
                // set the output back to standard out for running the test
                System.setOut(standardOut);
                // same for standard in
                System.setIn(standardIn);
                // add all tests to this method
                String appOutput = outputStreamCaptor.toString();
//                System.out.print(appOutput);
                if (frontend == null || !(appOutput.contains("Rookie | 20 | 3 years in LPL as a professional player | No degree | Game Tester | 94\n"
                        + "Kujo-Jotaro | 30 | 10 years as an oceanologist | PhD in UCBerkerley | Game Tester | 93\n"
                        + "Jason-Kazz | 40 | 15 years in New York Times | PhD from Harvard University | Main Designer | 92\n"
                        + "Miss-Fortune | 25 | 5 years as a professional shooter | No degree | Game Tester | 91\n"
                        + "Sun-Bofu | 33 | 10 years in Google | Graduate from Jiangdong University | Main Designer | 89\n"
                        + "Darius  | 38 | 8 years in Riot Game's Kitchen | No degree | Cook | 88\n"
                        + "Steve-Robinson | 31 | 2 years in Microsoft, 3 years in Apple. | Graduate from UWM | Senior Software Engineer | 87\n"
                        + "Galen | 38 | 8 years in Riot Game as a cleaner | No degree | Cleaner | 86\n"
                        + "Gimgoon | 24 | 2 years in LPL as a professional player | No degree | Game Tester | 83\n"
                        + "Lee-Sin | 29 | 7 years in Facebook | Graduate from UW | Program Manager | 82\n"
                        + "Yoshima-Naruto | 26 | 4 years in Riot Games | Undergraduate from CMU | Program Manager | 77\n"
                        + "Peter-Parker | 28 | 6 years in Marvel Studio | Graduate from Spider University | Programmer | 76\n"
                        + "James-Jobs | 22 | No working experience. | Undergraduate from UIUC | Programmer | 68\n"
                        + "Seraphine | 21 | 1 year in KDA | Undergraduate from Umich | Musician | 62\n"
                        + "Wu-Yifan | 31 | No working experience. | No degree | Cook | 60\n"
                        + "Wang-Sicong | 27 | No working experience. | Undergraduate from UCL | Programmer | 50\n"
                        + "Kelvin-Dell | 19 | No working experience. | Senior high school graduate | Data wrangler | 34\n"
                        + "Donald-Trump | 56 | 4 years as US president | No degree | Data wrangler | 23\n"
                        + "Vincent-Collector | 80 | 57 years in Gameloft | PhD from Cornell University | Programmer | 0") || !(appOutput.contains("Vincent Collector | 80 | 57 years in Gameloft | PhD from Cornell University | Programmer | 0\n"
                                + "Donald-Trump | 56 | 4 years as US president | No degree | Data wrangler | 23\n"
                                + "Jason-Kazz | 40 | 15 years in New York Times | PhD from Harvard University | Main Designer | 92\n"
                                + "Darius  | 38 | 8 years in Riot Game's Kitchen | No degree | Cook | 88\n"
                                + "Galen | 38 | 8 years in Riot Game as a cleaner | No degree | Cleaner | 86\n"
                                + "Sun-Bofu | 33 | 10 years in Google | Graduate from Jiangdong University | Main Designer | 89\n"
                                + "Steve-Robinson | 31 | 2 years in Microsoft, 3 years in Apple. | Graduate from UWM | Senior Software Engineer | 87\n"
                                + "Wu-Yifan | 31 | No working experience. | No degree | Cook | 60\n"
                                + "Kujo-Jotaro | 30 | 10 years as an oceanologist | PhD in UCBerkerley | Game Tester | 93\n"
                                + "Lee-Sin | 29 | 7 years in Facebook | Graduate from UW | Program Manager | 82\n"
                                + "Peter-Parker | 28 | 6 years in Marvel Studio | Graduate from Spider University | Programmer | 76\n"
                                + "Wang-Sicong | 27 | No working experience. | Undergraduate from UCL | Programmer | 50\n"
                                + "Yoshima-Naruto | 26 | 4 years in Riot Games | Undergraduate from CMU | Program Manager | 77\n"
                                + "Miss-Fortune | 25 | 5 years as a professional shooter | No degree | Game Tester | 91\n"
                                + "Gimgoon | 24 | 2 years in LPL as a professional player | No degree | Game Tester | 83\n"
                                + "James-Jobs | 22 | No working experience. | Undergraduate from UIUC | Programmer | 68\n"
                                + "Seraphine | 21 | 1 year in KDA | Undergraduate from Umich | Musician | 62\n"
                                + "Rookie | 20 | 3 years in LPL as a professional player | No degree | Game Tester | 94\n"
                                + "Kelvin-Dell | 19 | No working experience. | Senior high school graduate | Data wrangler | 34")))) {
                    fail();
                } 
            } catch (Exception e) {
                // make sure stdin and stdout are set correctly after we get exception in test
                System.setOut(standardOut);
                System.setIn(standardIn);
                e.printStackTrace();
                // test failed
                fail();
            }
        }

}

 
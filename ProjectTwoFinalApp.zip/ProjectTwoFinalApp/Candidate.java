// --== CS400 File Header Information ==--
// Name: Peichuan Yang
// Email: pyang248@wisc.edu
// Team: AC Red
// Role: Integration manager
// TA: Mu
// Lecturer: Florian
// Notes to Grader: <optional extra notes>
import java.util.List;

public class Candidate implements CandidateInterface {
  
  private String name;
  private int age;
  private int rating;
  private String workExperience;
  private String educationBackground;
  private String position;
  
  public Candidate(String name, int age, String workExperience, String educationBackground, String position, Integer rating) {
    this.name = name;
    this.age = age;
    this.rating = rating;
    this.workExperience = workExperience;
    this.educationBackground = educationBackground;
    this.position = position;
  }
  
  
  @Override
  public String getName() {
    return this.name;
  }

  @Override
  public int getRating() {
    return this.rating;
  }

  @Override
  public String getWorkExperience() {
    return this.workExperience;
  }

  @Override
  public String getEducationBackground() {
    return this.educationBackground;
  }

  @Override
  public String getPosition() {
    return this.position;
  }

  public int getAge() {
    return this.age;
  }

  @Override
  public int compareTo(CandidateInterface otherCandidate) {
    if(this.getRating()>otherCandidate.getRating()) return -1;
    else if (this.getRating() == otherCandidate.getRating()) return 0;
    return 1;
  }

  @Override
  public String toString() {
    return name + " | " + age + " | " + workExperience + " | " + educationBackground + " | " + position+" | " +  rating;
  }
}

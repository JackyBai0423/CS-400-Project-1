// --== CS400 File Header Information ==--
// Name: Jianbang Sun
// Email: jsun326@wisc.edu
// Team: AC Red
// Role: Backend Developer
// TA: Mu
// Lecturer: Florian
// Notes to Grader: <optional extra notes>
import java.util.List;

public interface BackendInterface {
    
    public void addAge(Integer age);
    public void addRating(Integer rating);
    public List<Integer> getAge();
    public List<Integer> getRatings();
    public int getNumberOfCandidates();
    public String getAllAges();
    public String getAllRatings();
    //return the information of a person with his name
    public String getSingleInfo(String Name); 

    
}